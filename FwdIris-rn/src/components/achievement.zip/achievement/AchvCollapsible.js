import React from 'react';
import {StyleSheet, ScrollView,View, Text,TouchableHighlight} from 'react-native';
import Collapsible from 'react-native-collapsible';
export class AchvCollapsible extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            collapsed:true
        };
    }

    render() {
        const {
            headerItem,
            blockItem,
            style,
        } = this.props;

        return (
            <View style={style}>
                <TouchableHighlight onPress={() => {
                    this.setState({ collapsed: !this.state.collapsed });
                }}>
                    {
                        headerItem()
                    }
                </TouchableHighlight>

                <Collapsible collapsed={this.state.collapsed} align="center">
                    {
                        blockItem()
                    }
                </Collapsible>
            </View>
        );
    }
}

