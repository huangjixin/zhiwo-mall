import React from 'react';
import {StyleSheet, ScrollView,View, Text} from 'react-native';

export class AchvIncomeItemHeader extends React.Component {
    static defaultProps = {
        arrows : true
    };
  render() {
  	const {
      itemTitl,
      subtotal,
        style,
        arrows,
    } = this.props;

    return (
          <View style={[{flexDirection: 'row'},style]}>
            <View style={{flex:8,marginLeft:10}}>
                <Text style={{fontSize:16}}>| {itemTitl}</Text>
            </View>
            <View style={{flex:8}}>
                <Text style={{marginLeft:50,textAlign:'left',color:'#FF9300',fontSize:16}}>小计：{subtotal}</Text>
            </View>
              <View style={{flex:1}}>
                  {arrows&&(
                      <Text style={{textAlign:'right'}}>∨</Text>
                  )
                  }
              </View>
           </View>
    );
  }
}

