import React from 'react';
import {StyleSheet, ScrollView, View,Text,TouchableHighlight} from 'react-native';

import {AchvIncomeItemHeader} from './AchvIncomeItemHeader'
import {AchvIncomeItemBlock} from './AchvIncomeItemBlock'
import * as Progress from 'react-native-progress';
import Collapsible from 'react-native-collapsible';
import Echarts from 'native-echarts';
import {AchvCollapsible} from "./AchvCollapsible";

export class AchvTabIncome extends React.Component {
    componentDidMount(){
        this.fetchData();
    }
    async fetchData() {
        console.log('***************Request Start********************');
        // console.log('Waiting response.. .. ..');
        //
        // await fetch('http://jsonplaceholder.typicode.com/albums')
        //     .then(response => response.json())
        //     .then(json => {
        //         const data = [];
        //         for(var i=0;i<4;i++){
        //             data.push(json[i]);
        //         }
        //
        //         //4.构建&更新state
        //         this.setState({
        //             data: data
        //         });
        //     })
        //     .catch((error) => {
        //         console.error(error);
        //     });

        console.log('***************Request End********************');
    }
  render() {
      option = {
          animation:false,
          tooltip : {
              trigger: 'item',
              formatter: "{a} <br/>{b} : {c} ({d}%)",
              show:false
          },
          legend: {
              show:false,
              orient : 'vertical',
              x : 'left',
              data:['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
          },
          toolbox: {
              show : false,
              feature : {
                  mark : {show: true},
                  dataView : {show: true, readOnly: false},
                  magicType : {
                      show: true,
                      type: ['pie', 'funnel'],
                      option: {
                          funnel: {
                              x: '25%',
                              width: '50%',
                              funnelAlign: 'center',
                              max: 1548
                          }
                      }
                  },
                  restore : {show: true},
                  saveAsImage : {show: true}
              }
          },
          calculable : false,
          series : [
              {
                  name:'income',
                  type:'pie',
                  radius : ['50%', '70%'],
                  itemStyle : {
                      normal : {
                          label : {
                              show : false
                          },
                          labelLine : {
                              show : false
                          }
                      },
                      // emphasis : {
                      //     label : {
                      //         show : false,
                      //         position : 'center',
                      //         textStyle : {
                      //             fontSize : '30',
                      //             fontWeight : 'bold'
                      //         }
                      //     }
                      // }
                  },
                  data:[
                      {value:1335, name:'直接访问'},
                      {value:310, name:'邮件营销'},
                      {value:234, name:'联盟广告'},
                      {value:135, name:'视频广告'},
                      {value:548, name:'搜索引擎'}
                  ]
              }
          ]
      };

    return (
        <View style={{backgroundColor:"#F7F7F7"}}>
	      <View style={styles.container}>
              <View style={{backgroundColor: 'white',height:190}}>
                  <View style={{marginTop:10}}>
                      <Text style={{marginLeft:10,fontSize:16}}>2018年1月收入 ▼</Text>
                  </View>
                  <View style={{marginTop:20,marginLeft:20,flexDirection:'row',justifyContent: 'center'}}>
                      <View style={{flex:2,flexDirection: 'row',justifyContent: 'center'}}>
                          <View style={{backgroundColor:'#F7F7F7',}}>
                              <Echarts
                                  option={option}
                                  height={120}
                                  width={120}/>
                          </View>
                      </View>
                      <View style={{marginLeft:20,flex:3,flexDirection: 'column',justifyContent: 'center'}}>
                          <Text style={{color:'#FF9300',marginTop:10,fontSize:28,fontWeight :'bold'}}>￥20,000.00</Text>
                          <Text style={{color:'black',marginTop:10,fontSize:18}}>税收：
                              <Text style={{color:'#FF9300',fontSize:18,fontWeight :'bold'}}>￥4,000.00</Text>
                          </Text>
                          <Text style={{color:'black',marginTop:10,fontSize:18}}>税后：
                              <Text style={{color:'#FF9300',fontSize:18,fontWeight :'bold'}}>￥16,000.00</Text>
                          </Text>
                      </View>
                  </View>
              </View>



              <View style={{backgroundColor: 'white',marginTop:10}}>
                  <View style={{marginTop:10}}>
                      <Text style={{color:'#FF9300',fontWeight:'200',fontSize:18}}>2018年1月收入明细</Text>
                  </View>


                  {/* item block */}
                  <AchvCollapsible
                      headerItem={()=>(
                          <AchvIncomeItemHeader style={styles.header}
                                                itemTitl='佣金类收入'
                                                subtotal='200,000'
                          />
                      )}
                      blockItem={()=>(
                          <View style={{flexWrap:'wrap',flexDirection: 'row',}}>
                              <AchvIncomeItemBlock
                                  itemTitl='首年佣金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='续期佣金'
                                  subtotal='10,000'
                              />
                          </View>
                      )}
                  />

                  {/* item block */}
                  <AchvIncomeItemHeader style={styles.header}
                      itemTitl='新人持续发展奖'
                      subtotal='2,000' arrows={false}
                  />
                  <View style={{marginTop:5}}>
                      <Text style={{marginLeft:10,fontSize:12}}>TIPS：剩余奖金6,000.00,将在2018/03/10逐月发放完毕。</Text>
                  </View>

                  {/* item block */}
                  <AchvCollapsible
                      headerItem={()=>(
                          <AchvIncomeItemHeader style={styles.header}
                                                itemTitl='个人销售收入'
                                                subtotal='3,000'
                          />
                      )}
                      blockItem={()=>(
                          <View style={{flexWrap:'wrap',flexDirection: 'row',}}>
                              <AchvIncomeItemBlock
                                  itemTitl='个人销售季度奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='个人季度连续销售奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='销售路线月度销售奖金'
                                  subtotal='10,000'
                              />
                          </View>
                      )}
                  />


                  {/* item block */}
                  <AchvCollapsible
                      headerItem={()=>(
                          <AchvIncomeItemHeader style={styles.header}
                                                itemTitl='团队管理奖金'
                                                subtotal='3,000'
                          />
                      )}
                      blockItem={()=>(
                          <View style={{flexWrap:'wrap',flexDirection: 'row',}}>
                              <AchvIncomeItemBlock
                                  itemTitl='月度直接管理奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='年度直接管理奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='月度所辖直接管理奖金'
                                  subtotal='10,000'
                              />
                          </View>
                      )}
                  />

                  {/* item block */}
                  <AchvCollapsible
                      headerItem={()=>(
                          <AchvIncomeItemHeader style={styles.header}
                                                itemTitl='增员与团队发展奖金'
                                                subtotal='3,000'
                          />
                      )}
                      blockItem={()=>(
                          <View style={{flexWrap:'wrap',flexDirection: 'row',}}>
                              <AchvIncomeItemBlock
                                  itemTitl='新人引荐奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='新人辅导奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='团队育成奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='新总监育部奖金'
                                  subtotal='10,000'
                              />
                              <AchvIncomeItemBlock
                                  itemTitl='育部奖金'
                                  subtotal='10,000'
                              />
                          </View>
                      )}
                  />

                  {/* item block */}
                  <AchvCollapsible
                      headerItem={()=>(
                          <AchvIncomeItemHeader style={styles.header}
                                                itemTitl='激励MDRT达成'
                                                subtotal='3,000'
                          />
                      )}
                      blockItem={()=>(
                          <View style={{flexWrap:'wrap',flexDirection: 'row',}}>
                              <AchvIncomeItemBlock
                                  itemTitl='直辖MDRT奖'
                                  subtotal='10,000'
                              />
                          </View>
                      )}
                  />

              </View>
	      </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container :{
    flexDirection: 'column',
    marginLeft :5,
    marginRight :5,
    marginBottom :10,
  },

    header: {
        backgroundColor: '#F5FCFF',
        paddingTop: 10,
    },
});

