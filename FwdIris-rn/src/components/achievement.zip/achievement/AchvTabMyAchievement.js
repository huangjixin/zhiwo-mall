import React from 'react';
import {StyleSheet, ScrollView, View, Text} from 'react-native';
import {AchvDountChart} from './AchvDountChart';
import {AchvTabMyAchievement_SM} from './AchvTabMyAchievement-SM';
import { AchvTabMyAchievement_SAM } from './AchvTabMyAchievement-SAM';
import { AchvTabMyAchievement_DD } from './AchvTabMyAchievement-DD';

export class AchvTabMyAchievement extends React.Component {
  render() {
    let random  = Math.random() * 10;
    let index = Math.round(random);
    // let MyAchievement = index < 3
    //   ? AchvTabMyAchievement_SM
    //   : (index >= 3 && index < 6
    //     ? AchvTabMyAchievement_SAM : AchvTabMyAchievement_DD);
    let MyAchievement =  AchvTabMyAchievement_DD;

    return (
      <MyAchievement></MyAchievement>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  }
});
