
import React from 'react';
import {StyleSheet, ScrollView,View, Text} from 'react-native';

export class AchvIncomeItemBlock extends React.Component {

  render() {
  	const {
      itemTitl,
      subtotal
    } = this.props;

    return (
    <View style={{marginLeft:15,marginTop:10,width:150,height:50,alignItems: 'center',flexDirection: 'row',justifyContent: 'center',borderWidth :0.5, borderColor:'#999999',}}>
	   	<View style={{width:70}}>
        <Text style={{marginRight:10 ,fontSize:12,textAlign:'center'}}>{itemTitl}</Text> 
      </View>
	   	<Text style={{fontSize:12,textAlign:'center'}}>{subtotal}</Text>
	  </View>
    );
  }
}



