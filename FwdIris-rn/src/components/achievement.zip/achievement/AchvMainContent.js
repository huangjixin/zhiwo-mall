import React from 'react';
import {StyleSheet, ScrollView, Text, View} from 'react-native';
import {TabNavigator, TabBarTop, TabBarBottom} from 'react-navigation';

import {AchvTabMyAchievement} from "./AchvTabMyAchievement";
import {AchvTabPromotion} from "./AchvTabPromotion";
import {AchvTabIncome} from "./AchvTabIncome";


const AchievementTabr = TabNavigator({
        AchvTabMyAchievement: {
            screen: AchvTabMyAchievement,
            navigationOptions: {
                tabBarLabel: '我的业绩',
            }
        }, 
        AchvTabPromotion: {
            screen: AchvTabPromotion,
            navigationOptions: {
                tabBarLabel: '晋升考核',
            }
        },
        AchvTabIncome: {
            screen: AchvTabIncome,
            navigationOptions: {
                tabBarLabel: '我的收入',
            }
        }, 
    },{
        tabBarOptions: {
            activeTintColor: '#FF9300',
            inactiveTintColor: '#000000',
            activeBackgroundColor: '#FF9300',
            inactiveBackgroundColor: '#FFFFFF',
            labelStyle: {
                fontSize: 16, // 文字大小
                paddingVertical:5,
                // borderBottomWidth:1,
                // borderBottomColor:'#FF9300',
                //padding:10
            },
            tabStyle: {
                backgroundColor: '#F7F7F7'
            },
            style: {
                height:32,
                textAlign:'center',
                paddingLeft:60,
                paddingRight:60,
                // borderBottomWidth:1,
                // borderBottomColor:'#FF9300',
                //paddingBottom:25
                backgroundColor: '#F7F7F7', // TabBar 背景色
                borderTopWidth:0,
                //height: 44,
                // width : 200,
                //lineHeight: 44,
            },
        },
        tabBarComponent: TabBarBottom,
        tabBarPosition: 'top',
        animationEnabled: false,
        swipeEnabled: false,
        lazy:true,
        backBehavior:'none'
    }
);

export class AchvMainContent extends React.Component {

  render() {
    return (
        <ScrollView style={{paddingTop:5}}>
            <AchievementTabr/>
        </ScrollView>

    );
  }
}