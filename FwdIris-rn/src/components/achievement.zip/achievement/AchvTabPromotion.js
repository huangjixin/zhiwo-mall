import React from 'react';
import {StyleSheet, ScrollView, Text, View} from 'react-native';
import {TabNavigator, TabBarTop, TabBarBottom} from 'react-navigation';

import {AchvPromStandardKeep} from "./AchvPromStandardKeep";
import {AchvPromStandardNext} from "./AchvPromStandardNext";

const PromTabBar = TabNavigator({
        standardNext: {
            screen: AchvPromStandardNext,
            navigationOptions: {
                tabBarLabel: '晋升下一职级标准',
            }
        },
        standardKeep: {
            screen: AchvPromStandardKeep,
            navigationOptions: {
                tabBarLabel: '维持当前职级标准',
            }
        },
    },{
        tabBarOptions: {
            activeTintColor: '#FFFFFF',
            inactiveTintColor: '#000000',
            activeBackgroundColor: '#FF9300',
            inactiveBackgroundColor: '#FFFFFF',
            labelStyle: {
                fontSize: 16, // 文字大小
                paddingVertical:5,
                //padding:10
            },
            style: {
                height:32,
                textAlign:'center',
                //paddingLeft:60,
                //paddingRight:60,
                //borderBottomWidth:1,
                //borderBottomColor:'gray'
                //paddingBottom:25
                backgroundColor: '#FFFFFF', // TabBar 背景色
                borderTopWidth:0,
                //height: 44,
                // width : 200,
                //lineHeight: 44,
            },
        },
        tabBarComponent: TabBarBottom,
        tabBarPosition: 'top',
        animationEnabled: false,
        swipeEnabled: false,
        backBehavior:'none'
    }
);

export class AchvTabPromotion extends React.Component {

  render() {
    return (
        <ScrollView style={{paddingTop:5}}>
            <PromTabBar/>
        </ScrollView>

    );
  }
}